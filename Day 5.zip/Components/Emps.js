import React from 'react';
import { Link } from 'react-router-dom';
import './Emps.css';

export default  function Emps()
{  
    let emps =  [
        { empno: 10, ename: "Ananya", job: "Full Stack Engineer", sal: 1500000, deptno: 101 },
        { empno: 20, ename: "Ishana", job: "QA Engineer", sal: 1000000, deptno: 102 },
        { empno: 30, ename: "Kashivi", job: "Data Analyst", sal: 1300000, deptno: 103 },
        { empno: 40, ename: "Navya", job: "Data Analyst", sal: 1200000, deptno: 104 },
        ];
        
 

    
 
        var result = emps.map( (item, index) => 
            <tr className={ index % 2 == 0?"c2":"c3" } >  
               <td> {item.empno}  </td> 
               <td> {item.ename}  </td> 
               <td> {item.sal}  </td> 
               <td> {item.job}  </td> 
               <td> {item.deptno}  </td> 
               <td align='center'>
                     <Link to={"/Details/" + item.empno}>Details</Link>
               </td>
            </tr>);

      return (
        <div>             
            <h3>All Employee Details</h3>
            <table  border="2"  cellpadding="5"  cellSpacing="0" width="700">
                <tr className="c1">
                    <th>Emp Number</th>
                    <th>Emp Name</th>
                    <th>Salary</th>
                    <th>Emp Job</th>
                    <th>Emp Deptno</th>    
                    <th></th>                
                </tr>
                {result}
            </table>
        </div>  );
    }
 

 