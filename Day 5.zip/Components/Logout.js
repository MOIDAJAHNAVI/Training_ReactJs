import React from 'react';
import { useNavigate } from "react-router-dom";

function Logout() {
    let navigate = useNavigate();

    function logout() {
        
        sessionStorage.removeItem('user-token');
        
        navigate("/");
    }

    return (
        <button onClick={logout}>Logout</button>
    );
}

export default Logout;