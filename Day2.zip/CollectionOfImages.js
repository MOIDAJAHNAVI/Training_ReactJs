import React from 'react';

function CollectionOfImages() {

    let  imgArray  = [ "img1.jpg", "img2.jpg", "img3.jpg", "img4.jpg", "img5.jpg"];
    let resArray = imgArray.map(item => <img src={"./"+item} width="100"></img>);


  return (
      <>
        <ul>
        {resArray}
        </ul>
      </>     
  );
}

export default CollectionOfImages;