import logo from './logo.svg';
import './App.css';
import EmpDetails from './EmpDetails';
import UserDetails from './UserDetails';
import CollectionOfImages from './CollectionOfImages'
import Images from './Images';

function App() {
  return (
    <>
    {/* <EmpDetails/> */}
    {/* <UserDetails/> */}
    {/* <CollectionOfImages/> */}
    <Images/>
    </>
  );
}

export default App;
