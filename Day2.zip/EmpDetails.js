import logo from './logo.svg';
import './App.css';
import React from 'react';

function EmpDetails() {
let empno = 101;
let ename = "Scott";
let job = "Developer";
let salary = 100000;
let depto = "Tax";

return (
    <>
    <h1> Employee Details</h1>
   
  
    <table border = "1"> 
     <th>
       <tr>Employee Number</tr>
       <tr>Employee Name</tr>
       <tr>Job</tr>
       <tr>Salary</tr>
       <tr>Depto</tr>
     </th>
     
     <th>
       <tr>{empno}</tr>
       <tr>{ename}</tr>
       <tr>{job}</tr>
       <tr>{salary}</tr>
       <tr>{depto}</tr>
     </th>
    
    </table>
 
  </>

);
}
export default EmpDetails;
