
import { useState } from "react";


function Products() {
   
   //pname, price, qty

    // For reading data from user through textboxes
    const [pname, setPname] = useState("");
    const [price, setPrice] = useState("");
    const [qty, setQty] = useState("");
    const [totalPrice, setTotalPrice] = useState("")

    const calculateTotalPrice = () => {
        let total = price*qty;
        
        if(qty>10 && qty<20)
        {
            total*=0.95;
        }
        if(qty>20 && qty<30)
        {
            total*=0.9;
        }else if (qty >= 30)
        {
            total *= 0.85;
        }
        setTotalPrice(total);
    }

    function TotalButton({onClick})
    {
        return <button onClick={onClick}>Calculate Total</button>
    }

    return (<>
        
        <hr />

        <fieldset>
            <legend>Product Details</legend>
            Product_Name  :  <input type="text" value={pname} onChange={(e) => setPname(e.target.value)} />
           <br/><br/>
            Price :  <input type="text" value={price} onChange={(e) => setPrice(e.target.value)} />
            <br/><br/>
            Quantity :  <input type="text" value={qty} onChange={(e) => setQty(e.target.value)} />
            <br/><br/>
            <TotalButton onClick={calculateTotalPrice}/>
            <p>Total Price; ${totalPrice}</p>
        </fieldset>
    </>);
}

export default Products;