import logo from './logo.svg';
import './App.css';
// import Products from './Products';
import Empdata from './Empdata';

function App() {
  return (
    <>
    {/* <Products/> */}
    <Empdata/>
    </>
  );
}

export default App;
